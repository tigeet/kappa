"use server";
import prisma from "@/db/db";
import { User } from "@prisma/client";

export async function getUploads(id?: string) {
  if (!id) return [];
  const uploads = await prisma.upload.findMany({
    where: {
      authorId: id,
    },
  });

  console.log("@get", uploads);
  return uploads;
}

export async function getLocalUploads(id?: string) {
  if (!id) return [];
  const uploads = await prisma.localUpload.findMany({
    where: {
      localId: id,
    },
  });
  // console.log("@getlocal", uploads);
  return uploads;
}
