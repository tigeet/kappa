"use client";
import { setSearchParam } from "@/utils/setSearchParam";
import { revalidatePath } from "next/cache";
import Image from "next/image";
import { useSearchParams, usePathname } from "next/navigation";
import { useRouter } from "next/navigation";
import ListIcon from "@/svg/align-left.svg";
import GridIcon from "@/svg/grid.svg";
import clsx from "clsx";
import { Layout } from "@/app/page";
export const LayoutButton = () => {
  const searchParams = useSearchParams();
  const pathname = usePathname();
  const router = useRouter();

  const layout = searchParams.get("layout") === "grid" ? "grid" : "list";

  const handleClick = (value: Layout) => {
    const params = setSearchParam({
      searchParams,
      pathname,
      key: "layout",
      value,
    });
    router.replace(params);
    router.refresh();
  };

  return (
    <div className="inline-flex  rounded-md justify-between overflow-hidden">
      <button
        onClick={() => handleClick("list")}
        className={clsx(
          "p-1 ",
          layout === "list" ? "bg-slate-600" : "bg-slate-800"
        )}
      >
        <ListIcon
          className={clsx(
            "w-4 h-4 ",
            layout === "list" ? "text-blue-500" : "text-white"
          )}
        />
      </button>

      <button
        onClick={() => handleClick("grid")}
        className={clsx(
          "  p-1",
          layout === "grid" ? "bg-slate-600" : "bg-slate-800"
        )}
      >
        <GridIcon
          className={clsx(
            "w-4 h-4 ",
            layout === "grid" ? "text-blue-500" : "text-white"
          )}
        />
      </button>
    </div>
  );
};
