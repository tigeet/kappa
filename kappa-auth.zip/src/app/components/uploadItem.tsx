"use client";
import { Layout } from "@/app/page";
import useHover from "@/hooks/useHover";
import { LocalUpload, Upload } from "@prisma/client";
import Image from "next/image";
import { useRef } from "react";
import MoreIcon from "@/svg/more-horizontal.svg";
import { usePathname, useRouter } from "next/navigation";
type Props = { upload: Upload | LocalUpload; view: Layout };

const UploadItem = ({ upload, view = "grid" }: Props) => {
  const [hover, ref] = useHover<HTMLDivElement>();

  const { language } = navigator;
  const displayDate = upload.uploadedAt.toLocaleDateString(language);

  if (view === "list")
    return (
      <div
        ref={ref}
        className="grid w-full h-12  grid-cols-[48px_1fr_128px_128px_24px] items-center justify-items-center"
      >
        <Image
          className="w-8 h-8 rounded-sm"
          key={upload.id}
          width="32"
          height="32"
          src={"https://kappa.lol/" + upload.id}
          alt={upload.filename + upload.extension}
        />
        <div className=" align-middle overflow-hidden w-full text-ellipsis whitespace-nowrap">
          {upload.filename + upload.extension}
        </div>
        <p>{upload.mimeType}</p>
        <p>{displayDate}</p>
        <button>
          <MoreIcon className="w-6 h-6 text-white" />
        </button>
      </div>
    );
  return (
    <div
      className="flex flex-col px-4 py-4  gap-2 rounded-md bg-slate-700 relative"
      ref={ref}
    >
      <Image
        className="w-full flex-1 aspect-square"
        key={upload.id}
        width="256"
        height="256"
        src={"https://kappa.lol/" + upload.id}
        alt={upload.filename + upload.extension}
      />
      <div className="flex-0 flex justify-center">
        <p className=" overflow-hidden text-ellipsis whitespace-nowrap">
          {upload.filename + upload.extension}
        </p>
      </div>
      {hover && (
        <button className="absolute top-1 right-1 rounded-full bg-slate-200 w-5 h-5 flex items-center justify-center">
          <MoreIcon className="w-4 h-4 text-blue-500" />
        </button>
      )}
    </div>
  );
};

export default UploadItem;
