"use client";
import prisma from "@/db/db";
import getUser from "@/utils/getUser";
import Image from "next/image";
import Link from "next/link";
import UploadField from "./components/uploadField/upload";
import styled from "styled-components";
import { LayoutButton } from "./components/layoutButton";
import UploadItem from "./components/uploadItem";
import clsx from "clsx";
import { useQuery } from "@tanstack/react-query";
import { getLocalUploads, getUploads } from "./actions";
import makeHex from "@/utils/makeHex";
import useLocalStorage from "@/hooks/useLocalStorage";
import useLocalId from "@/hooks/useLocalId";
import { getLocalId } from "@/utils/localId";
// import { getLocalId } from "@/utils/localId";
// export const dynamic = "force-dynamic";
// export const revalidate = 0;

export type Layout = "grid" | "list";
type Props = {
  searchParams: Record<string, undefined | string | string[]>;
};
export default function Home({ searchParams }: Props) {
  const { data } = useQuery({
    queryKey: ["uploads"],
    queryFn: async () => {
      const user = await getUser();
      const localId = getLocalId();
      const uploads = (
        await Promise.all([
          await getUploads(user?.id),
          await getLocalUploads(localId),
        ])
      )

        .flat()
        .sort((a, b) => a.uploadedAt.getTime() - b.uploadedAt.getTime());

      return { user, uploads };
    },
  });
  if (!data) {
    return;
  }
  const { user, uploads } = data;
  const layout: Layout = searchParams.layout === "grid" ? "grid" : "list";
  return (
    <main className="flex flex-1 md:flex-row flex-col-reverse px-4 md:gap-8 gap-4">
      <div className="flex-1 flex flex-col gap-4">
        <div className="flex-0">
          <LayoutButton />
        </div>

        <div
          className={clsx(
            "flex  ",
            layout === "list"
              ? "flex-col gap-2 "
              : "gap-4 grid auto-fill-[256px]"
          )}
        >
          {uploads.map((upload) => (
            <UploadItem key={upload.id} upload={upload} view={layout} />
          ))}
        </div>
      </div>

      <div className="flex flex-0">
        <UploadField />
      </div>
    </main>
  );
}
